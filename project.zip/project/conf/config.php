<?php
$koneksi = mysqli_connect('localhost','root','','db_sistem_informasi');
// // Mengecek koneksi
// if(!$koneksi){
//     die("Koneksi Gagal:". mysqli_connect_error());
// }
// else{
//     echo "Koneksi Berhasil";
// }
?>