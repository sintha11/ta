<?php
echo $_GET['bulan'];
echo $_GET['indikator kinerja'];
echo $_GET['program kegiatan'];
echo $_GET['target kinerja'];
echo $_GET['realisasi kinerja'];
echo $_GET['pencapaian kinerja'];
echo $_GET['permasalahan'];
?>