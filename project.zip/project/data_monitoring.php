
<!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Data Monitoring Kinerja Satuan Polisi Pamong Praja Kota Malang</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-lg">
                  Tambah Data
                </button>
                <br></br>
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Bulan</th>
                    <th>Indikator Kinerja</th>
                    <th>Program Kegiatan</th>
                    <th>Target Kinerja</th>
                    <th>Realisasi Kinerja</th>
                    <th>Pencapaian Kinerja</th>
                    <th>Permasalahan</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  </tbody>
                    <?php
                    $no = 0;
                    $query = mysqli_query($koneksi,"SELECT * FROM tb_monitoring");
                    while($mnt = mysqli_fetch_array($query)){
                      $no++
                    ?>
                    <tr>
                    <td width='3%'><?php echo $no;?></td>
                    <td><?php echo $mnt['Bulan'];?></td>
                    <td><?php echo $mnt['Indikator Kinerja'];?></td>
                    <td><?php echo $mnt['Program Kegiatan'];?></td>
                    <td><?php echo $mnt['Target Kinerja'];?></td>
                    <td><?php echo $mnt['Realisasi Kinerja'];?></td>
                    <td><?php echo $mnt['Pencapaian Kinerja'];?></td>
                    <td><?php echo $mnt['Permasalahan'];?></td>
                    <td>X</td>
                  </tr>
                    <?php }?>
                  </tbody>
                  <tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Data Monitoring Kinerja</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form method="get" action="add/tambah_data.php">
            <div class="modal-body">
          
                <div class="form-row">
                  <div class="col">
                    <input type="text" class="form-control" placeholder="Bulan" name="bulan">
                  </div>
                  <div class="col">
                    <input type="text" class="form-control" placeholder="Indikator Kinerja" name="indikator kinerja">
                  </div>
                  <div class="col">
                    <input type="text" class="form-control" placeholder="Program Kegiatan" name="program kegiatan">
                  </div>
                  <div class="col">
                    <input type="text" class="form-control" placeholder="Target Kinerja" name="target kinerja">
                  </div>
                  <div class="col">
                    <input type="text" class="form-control" placeholder="Realisasi Kinerja" name="realisasi kinerja">
                  </div>
                  <div class="col">
                    <input type="text" class="form-control" placeholder="Pencapaian Kinerja" name="pencapaian kinerja">
                  </div>
                  <div class="col">
                    <input type="text" class="form-control" placeholder="Permasalahan" name="permasalahan">
                  </div>
                </div>
              
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </div>
          </form>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
