<?php
session_start();
unset($_SESSION['Nama']);
unset($_SESSION['Level']);
header('Location: ../');
?>